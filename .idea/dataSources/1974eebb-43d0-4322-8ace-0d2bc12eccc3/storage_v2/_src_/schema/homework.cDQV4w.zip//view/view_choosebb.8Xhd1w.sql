create view view_choosebb as
select `homework`.`choosebb`.`Bb1` AS `View_bb1`,
       `homework`.`choosebb`.`Bb4` AS `View_bb2`,
       `homework`.`choosebb`.`Bb5` AS `View_bb3`
from `homework`.`choosebb`;

